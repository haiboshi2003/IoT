---
title: "同济大学”天行“气象预测平台上线了！"
date: "2023-08-09"
image: 'https://tianxing.tongji.edu.cn/imgs/News/logo.png'
---

这里是新闻的内容1...