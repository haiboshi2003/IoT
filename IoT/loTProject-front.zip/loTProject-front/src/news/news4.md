---
title: "新闻标题4"
date: "2023-05-04"
image: 'https://tianxing.tongji.edu.cn/imgs/News/title.png'
---

这里是新闻的内容4...