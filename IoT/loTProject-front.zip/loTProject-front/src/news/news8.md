---
title: "新闻标题8"
date: "2023-05-03"
image: 'https://tianxing.tongji.edu.cn/imgs/News/home_image.png'
---

这里是新闻的内容8...