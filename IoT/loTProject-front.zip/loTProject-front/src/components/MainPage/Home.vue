<script setup>

</script>

<template>
  <div class="pageContent">
    <div class="title">
      <br>
      同济大学智慧大气与智慧海洋实验室
    </div>

    <div class="img_1">
      <img style="height: 350px" src="../../assets/home_image.png" alt="">
    </div>
    <div class="text">
      <p>
        同济大学软件学院智慧大气与智慧海洋研究团队主要由两名正教授及其指导下的10名博士生和10名硕士生所组成。主要从事人工智能与地球科学的交叉科学研究。研究方向涵盖：人工智能及其可解释性、机器学习、大气及海洋大数据分析等。当前主持国家自然科学基金重点联合基金项目一项、国家自然科学基金面上项目一项、国家重点研发计划课题两项、以及上海市科委重点课题一项。团队在该研究方向已发表学术论文120余篇，获授国家发明专利11项。团队研究地点：同济大学嘉定校区济事楼307实验室。
      </p>
    </div>
  </div>
</template>

<style scoped lang="scss">
  .title{
    font-weight:600;
    font-size:160%;
    line-height: 180%;
    text-align: center;
  }
  .img_1{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 400px;
  }
  .text{
    font-weight:400;
    font-size:120%;
    text-align: justify;
  }
</style>