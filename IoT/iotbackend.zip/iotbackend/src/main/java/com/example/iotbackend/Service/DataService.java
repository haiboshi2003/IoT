package com.example.iotbackend.Service;

import com.example.iotbackend.pojo.Data;

import java.time.LocalDateTime;
import java.util.List;

public interface DataService {


    List<Data> getAllData();


    List<Data> getByDate(LocalDateTime date, LocalDateTime nextDate);

    List<Data> getPredate(LocalDateTime startDate, LocalDateTime nextDate);
}
