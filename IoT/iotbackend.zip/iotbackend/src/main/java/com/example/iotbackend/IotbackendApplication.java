package com.example.iotbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IotbackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(IotbackendApplication.class, args);
    }

}
