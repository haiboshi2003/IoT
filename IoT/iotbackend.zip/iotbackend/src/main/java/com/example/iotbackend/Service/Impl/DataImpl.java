package com.example.iotbackend.Service.Impl;

import com.example.iotbackend.Service.DataService;
import com.example.iotbackend.mapper.DataMapper;
import com.example.iotbackend.pojo.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DataImpl implements DataService {
    @Autowired
    DataMapper dataMapper;

    @Override
    public List<Data> getAllData() {
        return dataMapper.getAllData();
    }

    @Override
    public List<Data> getByDate(
            LocalDateTime date, LocalDateTime nextDate) {
        return dataMapper.getByDate(date, nextDate);
    }

    @Override
    public List<Data> getPredate(LocalDateTime startDate, LocalDateTime nextDate) {
        return dataMapper.getPredate(startDate, nextDate);
    }


}
