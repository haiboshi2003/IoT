package com.example.iotbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IotbackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
